+++ B r i t n e y  A m p v1.0  for WinAmp by Victoria Masheva +++
Not to be reproduced in whole or in part without written permission of Victoria!

***Thank you for downloading this skin.
For best results use WinAmp 2.0 or higher. 
Check www.winamp.com for the latest
release of WinAmp.

***How to install: unzip into your WinAmp
skins folder.(ex. c:\program files\winamp\Skins\ )
load up WinAmp and popup the window;'Skin Browser'
(=press 'Alt'+'S'), select 'BritneyAmp'.

***With playlist, equalizer and minibrowser.

***Comments and suggestions to:
	Victoria Masheva
	victoria@acvilon.com

or check out: http://britney.search.bg



(c)1999			All copyrights reserved.