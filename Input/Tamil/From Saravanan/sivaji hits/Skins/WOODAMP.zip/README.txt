WoodAmp v1.0A by Magnus Bengtsson
=================================
The only change from v1.0 to v1.0A is that I've
bundled a customization of the WinAmp speakers.
Please read the Plugins\vis_wosp.txt file for
credits.

WoodAmp and the WoodAmp speakers is designed for
16 bit color depth or more.

Please email me and tell me if you liked the WoodAmp
Skin: fambsson@hem.passagen.se

Do visit my skin site: http://hem.passagen.se/fambsson/ampskins.html

March 21, 1998,
Magnus Bengtsson.

Installation
------------
Extract the woodamp.zip archive file into the WinAmp
root directory. This should copy the vis_wosp.dll and
vis_wosp.txt files to the Plugins directory, and the
rest of the files to the Skins/WoodAmp directory.


Revision history
----------------
V1.0A, March 21, 1998
Bundled WinAmp speakers.

V1.0, March 17, 1998
First edition.