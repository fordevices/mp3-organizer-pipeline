Visual Odyssey's Voyager 1 AMP
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Requirements
~~~~~~~~~~~~
This skin uses "balance.bmp" so you must have WinAMP 1.91+. If you see a "hole" in the skin, 
grab the new version of WinAMP.


Installation/Troubleshooting
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Simply unzip this archive into a new folder in your "winamp/skins" directory.  For example, 
you may wish to install this skin into "winamp/skins/voyager/"


What you get
~~~~~~~~~~~~
1) The graphics necessary to run this skin.
2) The graphic this skin originated from.  Check it out! It's called "boundless.jpg" and is located
   with the skin files.


Who is Visual Odyssey?
~~~~~~~~~~~~~~~~~~~~~~
Visual Odyssey is an energetic, forward thinking, bold company of graphic designers, and 
illustrators. Visual Odyssey offers an extensive range of marketing solutions including graphic 
design, product illustration, Internet problem solving, marketing strategies and 3D design. 
Our company offers these quality services at an affordable rate. 


	Come experience what Visual Odyssey can do for you!

	Visual Odyssey
	http://www.visualodyssey.com




Version 1.0 Bundled: Aug., 06 '98